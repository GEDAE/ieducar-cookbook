SET search_path = public;

DROP FUNCTION pgrowlocks(text);

DROP TYPE pgrowlocks_type;
