-- Adjust this setting to control where the objects get created.
SET search_path = public;

DROP VIEW pg_buffercache;

DROP FUNCTION pg_buffercache_pages();
