typedef struct SEG
{
	float		lower;
	float		upper;
	char		l_sigd;
	char		u_sigd;
	char		l_ext;
	char		u_ext;
}	SEG;
