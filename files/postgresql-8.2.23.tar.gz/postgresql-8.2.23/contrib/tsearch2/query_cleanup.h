#ifndef __REWRITE_H__
#define __REWRITE_H__

#include "query.h"

ITEM	   *clean_NOT_v2(ITEM * ptr, int4 *len);
ITEM	   *clean_fakeval_v2(ITEM * ptr, int4 *len);

#endif
